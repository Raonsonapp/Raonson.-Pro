# Web Benchmark Tests

This directory, `lib/benchmarks/`, is used for performance testing for the Gallery on Web.

It is used by `web_benchmarks` in the Flutter repository to collect benchmarks that
indicate Gallery's performance.

For more information, especially how to run these tests, see:

https://github.com/flutter/flutter/tree/master/dev/benchmarks/macrobenchmarks#web-benchmarks
