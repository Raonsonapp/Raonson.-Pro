# l10n

A command-line application that converts .arb files to .xml files for
translation consumption.